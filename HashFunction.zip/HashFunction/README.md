## String hash functions

Folders `all` and `flatten` are tests for string hash functions of the form

$$\left( \text{parseInt}\left(x\right)\mod m_1\right) \mod m_2 = 0$$

$x$ is a decimal string, $m_1$ is a large number (usually prime), and $m_2<m_1$.

For example, 
$$\left( \text{parseInt}\left(''123456789''\right)\mod 100009\right) \mod 10000 = 0$$

## Tests

In `flatten\head-tail`, the string $x$ is of the form
$$12345(a)^+(b)^+6789$$
where $1\le a,b<100$ are the loop bodies, the task is to decide the number of loops for $a$ and $b$.

For instance, in `test1` $(a,b)=(51,69)$, $(m_1,m_2)=(929,202)$, translating into `smt2` gives 

```
(set-logic QF_SLIA)
(set-option :produce-models true)
(declare-fun x () String)
(assert (str.in_re x (re.++ (str.to_re "12345") (re.+ (str.to_re "51")) (re.+ (str.to_re "69"))(str.to_re "6789"))))
(assert (= (mod (mod (str.to_int x) 929) 202) 0))
(assert (< (str.len x) 100))
(check-sat)
(get-model)
```

For Trau, we use `trautest1` where `str.to_re`, `str.in_re` and `str.to_int` are changed to `str.to.re`, `str.in.re` and `str.to.int`, without changing anything else.

CVC4,Z3 find that $1234551516969696789$ satisfies the constraints. But Trau asserts unsat.

In folder `all`, $x$ is of the form 
$$12345(\Sigma^*)6789$$
where $\Sigma^*$ can be arbitrary string (length less than 100).

For `tail`, `head` and `head-tail` subfolders, it corresponds to 
- tail: $(a)^+(b)^+6789$
- head: $12345(a)^+(b)^+$
- head-tail: $12345(a)^+(b)^+6789$

## Result

It seems Trau
- will assert `unsat` for some satisfiable cases, see `\flat\head-tail\test1` and `\all\head-tail`

- confuse regular operation `re.+` with `re.*`, see `\flat\head-tail\test21`